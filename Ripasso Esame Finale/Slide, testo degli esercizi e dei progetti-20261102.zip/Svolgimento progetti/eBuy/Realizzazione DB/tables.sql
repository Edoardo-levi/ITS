create table categoria (
	nome stringa primary key,
	super stringa, -- non è not null perché può non avere una super-categoria
	foreign key (super)
		references categoria(nome),
	check (nome <> super)
);

create table metodopagamento (
	nome stringa primary key
);

create table utente(
	username stringa primary key,
	registrazione timestamp not null
);

create table privato (
	utente stringa primary key,
	foreign key (utente)
		references utente(username)
);

create table venditoreprof (
	utente stringa primary key,
	vetrina URL not null,
	foreign key (utente)
		references utente(username)
);

create table postoggetto (
	id serial primary key,
	pubblica stringa not null,
	unique(id, pubblica), -- chiave non-minimale, serve per la FK da postoggettonuovo
	descrizione stringa not null,
	pubblicazione timestamp not null,
	ha_feedback boolean not null,
	voto Voto,
	commento stringa,
	istante_feedback timestamp,
	-- vincoli di ennupla che implementano [V.PostOggetto.feedback]
	check(
		(ha_feedback = true and voto is not null and istante_feedback is not null)
		or 
		(ha_feedback = false and voto is null and istante_feedback is null and commento is null)
	),

	foreign key (pubblica)
		references utente(username),
	categoria stringa not null,
	foreign key (categoria)
		references categoria(nome)
);

create table met_post (
	postoggetto integer not null,
	metodo stringa not null,
	foreign key (postoggetto)
		references postoggetto(id),
	foreign key (metodo)
		references metodopagamento(nome),
	primary key (postoggetto, metodo)
);

create table postoggettonuovo(
	postoggetto integer not null,
	
	anni_garanzia intge2 not null,
	pubblica_nuovo stringa not null,
	foreign key (postoggetto, pubblica_nuovo)
		references postoggetto(id, pubblica),
	foreign key (pubblica_nuovo)
		venditoreprof(utente)
);

Utente
u1
u2
u3

Privato
u1

Venditoreprof
u2
u3

PostOggetto
id		pubblica
p1			u2
p2			u1

PostOggettoNuovo
postoggetto		pubblica_nuovo
p1					u2

PostOggettoUsato

p2

create table postoggettousato(
	postoggetto integer not null,
	
	anni_garanzia intgez not null,
	condizione condizione not null
	foreign key (postoggetto)
		references postoggetto(id)
);


create table postoggettocompralosubito(
	postoggetto integer not null,
	prezzo realgz not null,
	acquirente stringa, -- accorpa l'associazione 'acquirente'
	istante_acquisto timestamp,
	check (
		(acquirente is null and istante_acquisto is null)
		or
		(acquirente is not null and istante_acquisto is not null)
		),
	foreign key (postoggetto)
		references postoggetto(id),
	foreign key (acquirente)
		references privato(utente)
);

create table postoggettoasta(
	postoggetto integer not null,
	prezzo_base realgez not null,
	prezzo_base realgz not null,
	scadenza timestamp not null,
	foreign key (postoggetto)
		references postoggetto(id)
);

create table bid(
	codice serial primary key,
	privato stringa not null,
	foreign key (privato)
		references privato(utente),
	asta integer not null,
	foreign key (asta)
		references postoggettoasta(postoggetto),
	istante timestamp not null,
	unique(asta, istante) -- {id2} nel diagramma delle classi
);



